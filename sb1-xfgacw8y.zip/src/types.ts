// ... (garder tout le code existant jusqu'à l'interface Testimonial)

export interface Testimonial {
  id: number;
  name: string;
  role: string;
  quote: string;
}

// ... (garder le reste du code)